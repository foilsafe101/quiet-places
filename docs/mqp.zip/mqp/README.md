# Quiet Places — Map of Quiet Places (MQP)

A dynamic web map showing where on Earth you can stand without hearing any human-made sound: no airplanes, roads, trains, or industry.

## How it works

1. **`fetch_flights.py`** runs nightly (via GitHub Actions) and fetches real flight tracks from the OpenSky Network API
2. Tracks are appended to **`docs/flights.json`** with timestamps, then committed back to the repo
3. GitHub Pages serves `docs/index.html` — a Leaflet map that loads `flights.json` and draws each track colored by age (bright red = recent, near-black = old)

## Setup

### 1. Fork / clone this repo

```bash
git clone https://github.com/YOUR_USERNAME/quiet-places
cd quiet-places
```

### 2. Enable GitHub Pages

In your repo settings → Pages → Source: **Deploy from branch** → branch: `main`, folder: `/docs`

Your map will be live at `https://YOUR_USERNAME.github.io/quiet-places/`

### 3. Create the initial flights.json

Run the fetch script locally first to seed the data file:

```bash
pip install -r requirements.txt
python fetch_flights.py --hours 48
```

Commit and push `docs/flights.json`.

### 4. Enable GitHub Actions

The workflow at `.github/workflows/fetch-nightly.yml` runs automatically at 4am UTC.
It needs write access to commit `flights.json` — this is already configured in the workflow file.

To trigger it manually: Actions tab → "Fetch nightly flight data" → Run workflow.

## Configuration

Edit the top of `fetch_flights.py` to adjust:

| Setting | Default | Description |
|---|---|---|
| `ACTIVE_BOUNDS` | `"global"` | Geographic region to fetch (`"north_america"`, `"europe"`, `"global"`) |
| `SAMPLE_EVERY_N` | `10` | Take 1 track per N flights (controls density vs. API usage) |
| `MAX_TRACKS_PER_RUN` | `80` | Hard cap per nightly run |
| `WAYPOINT_STRIDE` | `3` | Keep every Nth waypoint (reduce file size) |

`--prune-days` in the workflow defaults to 180 (6 months). Increase for denser historical webs.

## OpenSky Research Access

The free OpenSky API returns ~2 hours of history and rate-limits aggressively.
For the full historical dataset (2013–present), apply for research access at:
https://opensky-network.org/data/impala

This is free for non-commercial research. The fetch script will work with research credentials — just set `OPENSKY_USERNAME` and `OPENSKY_PASSWORD` environment variables (stored as GitHub Actions secrets).

## File structure

```
quiet-places/
├── fetch_flights.py              # nightly data fetch script
├── requirements.txt
├── .github/
│   └── workflows/
│       └── fetch-nightly.yml     # GitHub Actions schedule
└── docs/                         # served by GitHub Pages
    ├── index.html                # the map
    └── flights.json              # accumulated flight tracks (auto-updated)
```

## License

Research / non-commercial use. Flight data © OpenSky Network contributors.
